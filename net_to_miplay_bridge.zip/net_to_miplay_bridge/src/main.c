/*
 * @Author: p-caozhanpeng p-caozhanpeng@xiaomi.com
 * @Date: 2025-04-14 16:19:57
 * @LastEditors: caozhanpeng caozhanpeng@xiaomi.com
 * @LastEditTime: 2025-04-14 16:10:59
 * @FilePath: /vendor/xiaomi/miai/net_to_miplay_bridge/main.c
 * @Description: net communicate to miplay
 */

#include <syslog.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <spawn.h>
#include "builtin/builtin.h"

#define MPAS_PID                14
#define MPAS_TASK_NAME          "mpas"

/**
 * @description:  startup application
 * @param {const char*} taskName
 * @param {size_t} taskStackSize
 * @return {int} errno
 */
static int startup_application(const char* taskName, size_t taskStackSize)
{
    FAR const struct builtin_s* builtin;
    posix_spawnattr_t attr;
    int ret = 0;
    int index;
    pid_t pid;

    /*Verify that an application with this name exists */
    index = builtin_isavail(taskName);
    if(index < 0)
    {
        syslog(LOG_ERR,"%s get builtin isavail error!!\n", taskName);
        ret = ENOENT;
        return ret;
    }

    /* Get information about the builtin */
    builtin = builtin_for_index(index);
    if(builtin == NULL){
        syslog(LOG_ERR,"%s get builtin index error\n",taskName);
        ret = ENOENT;
        return ret;
    }

    posix_spawnattr_init(&attr);
    posix_spawnattr_setstacksize(&attr, taskStackSize);

#ifdef CONFIG_LIBC_EXECFUNCS
    /* Load and execute the application.*/
    ret = posix_spawn(&pid, builtin->name, NULL, &attr, NULL, NULL);
    if(ret !=0 && builtin->main != NULL)
#endif
    {
        pid = task_spawn(builtin->name, builtin->main, NULL, &attr, NULL, NULL);
        ret = pid < 0 ? -pid : 0;
    }

    if(ret != 0)
    {
        syslog(LOG_ERR,"ERROR: task spawn failed: %d\n",ret);
        ret = ENOENT;
    }

    posix_spawnattr_destroy(&attr);
    return ret;
}

/**
 * @description:  main task
 * @param {int} argc
 * @param {char} *argv
 * @return {*}
 */
int main(int argc, char *argv[])
{
    int ret = 0;
    int kill_retry_count = 0;
    int startup_retry_count = 0;

    if(access("/data/mico/msg/is_bind", F_OK) == 0)
    {
        syslog(LOG_DEBUG,"net_to_miplay_bridge:device has binded!!\n");
        return 0;
    }

    while(access("/data/mico/msg/is_bind", F_OK) != 0)
    {
        syslog(LOG_DEBUG,"net_to_miplay_bridge:wait net connected!!\n");
        sleep(1);
    }

    syslog(LOG_INFO,"net_to_miplay_bridge:send kill to miplay!!\n");
kill_retry:
    if(kill_retry_count >= 3)
    {
        syslog(LOG_ERR,"net_to_miplay_bridge:can't kill!!\n");
        return 0;
    }
    if (kill(MPAS_PID, SIGTERM) == -1) {
        syslog(LOG_ERR,"net_to_miplay_bridge:kill failure: %d!!\n", errno);
        kill_retry_count++;
        goto kill_retry;
    }
    syslog(LOG_INFO,"net_to_miplay_bridge:kill success!!\n");

    sleep(1);//wait 1s

    syslog(LOG_INFO,"net_to_miplay_bridge:startup miplay!!\n");
startup_retry:
    if(startup_retry_count >= 3)
    {
        syslog(LOG_ERR,"net_to_miplay_bridge:can't startup!!\n");
        return 0;
    }
    ret = startup_application(MPAS_TASK_NAME, 4096);
    if(ret != 0)
    {
        syslog(LOG_ERR,"net_to_miplay_bridge:startup failure: %d!!\n", ret);
        startup_retry_count++;
        goto startup_retry;
    }
    syslog(LOG_INFO,"net_to_miplay_bridge:startup success!!\n");

    return 0;
}
